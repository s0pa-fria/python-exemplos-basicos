# Lista usando o laço for
print("")
print("======== TIMES ========")
print("")

times = ["Corinthians", "São Paulo", "Flamengo", "Vasco"]

# Lista usando laço
for time in times:
    print(time)