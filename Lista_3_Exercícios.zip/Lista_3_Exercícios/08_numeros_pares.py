# Lista com os valores de 1 até 10 com while 
print("Exibindo uma lista com os valores de 1 até 10: ")
i = 1

while i <= 10: 
    print(i)
    i += 1

# Exibindo apenas os números pares com while
print(" ")
print("Exibindo apenas os números pares: ")
i = 2

while i <= 10: 
    print(i)
    i += 2